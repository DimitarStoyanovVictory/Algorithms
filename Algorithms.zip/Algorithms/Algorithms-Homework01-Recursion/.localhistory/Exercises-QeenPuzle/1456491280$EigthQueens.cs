﻿namespace Exercises_QeenPuzle
{
    public class EigthQueens
    {
        static void Main()
        {

        }
    }
}
