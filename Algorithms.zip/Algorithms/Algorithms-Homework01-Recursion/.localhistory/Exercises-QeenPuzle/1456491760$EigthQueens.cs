﻿namespace Exercises_QeenPuzle
{
    public class EigthQueens
    {
        const int Size = 8;
        static bool[,] chessboard = new bool[Size, Size];


        static void Main()
        {

        }
    }
}
