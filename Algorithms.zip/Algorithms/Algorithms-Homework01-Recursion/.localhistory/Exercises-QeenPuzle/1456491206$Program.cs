﻿namespace Exercises_QeenPuzle
{
    public class QueensPuzlle
    {
        static void Main(string[] args)
        {
        }
    }
}
