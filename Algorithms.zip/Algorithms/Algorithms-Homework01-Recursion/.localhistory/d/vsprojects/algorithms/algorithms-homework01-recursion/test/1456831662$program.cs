﻿using System;
using System.Collections;

public class Program
{
    static void Main()
    {
        var queue = new Queue();

        queue.Enqueue(1);
        queue.Enqueue(2);
        queue.Enqueue(3);

        Console.WriteLine(stack.Peek());
    }
}
