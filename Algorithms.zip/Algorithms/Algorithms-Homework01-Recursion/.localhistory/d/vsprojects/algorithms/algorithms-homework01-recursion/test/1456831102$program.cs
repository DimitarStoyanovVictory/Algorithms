﻿using System;
using System.IO;
using System.Linq;

public class Program
{
    static void Main()
    {
        
    }
}
