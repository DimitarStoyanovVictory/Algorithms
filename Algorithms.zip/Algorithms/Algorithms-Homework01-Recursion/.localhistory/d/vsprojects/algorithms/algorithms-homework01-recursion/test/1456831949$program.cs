﻿using System;
using System.Collections;
using System.Collections.Generic;

public class Program
{
    static void Main()
    {
        var queue = new LinkedList<>();

        Console.WriteLine(queue);
    }
}
