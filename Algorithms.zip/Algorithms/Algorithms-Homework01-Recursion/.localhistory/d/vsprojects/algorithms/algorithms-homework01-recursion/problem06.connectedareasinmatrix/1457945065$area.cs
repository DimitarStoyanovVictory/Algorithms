﻿namespace Problem06.ConnectedAreasInMatrix
{
    using System.Collections.Generic;

    public class Area
    {

        public SortedSet<AreaPoint> AreaPoints { get; } = new SortedSet<AreaPoint>();

    }
}
