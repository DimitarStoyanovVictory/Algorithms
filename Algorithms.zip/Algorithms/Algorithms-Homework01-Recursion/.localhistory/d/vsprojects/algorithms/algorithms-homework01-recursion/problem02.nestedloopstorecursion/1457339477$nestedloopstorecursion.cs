﻿using System;
using System.Linq;

class NestedLoopsToRecursion
{
    
    static void Main()
    {
        
    }
}
