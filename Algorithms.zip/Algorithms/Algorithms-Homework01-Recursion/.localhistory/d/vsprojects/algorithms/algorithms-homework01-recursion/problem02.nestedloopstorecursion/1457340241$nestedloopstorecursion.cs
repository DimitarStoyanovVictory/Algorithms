﻿class NestedLoopsToRecursion
{
    static void Main()
    {
        
    }
}
