﻿using System;

public class TowerOfHanoi
{
    public static void Main()
    {
        Console.WriteLine("Pleace enter the number of dist of tower of Hanoi");
    }
}
