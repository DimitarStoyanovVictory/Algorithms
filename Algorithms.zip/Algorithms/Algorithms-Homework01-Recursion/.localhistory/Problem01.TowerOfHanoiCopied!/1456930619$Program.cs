﻿using System;

public class TowerOfHanoi
{
    public static void Main()
    {
        Console.Write("Pleace enter the number of dist of tower of Hanoi; n = ");
        int n = int.Parse();
    }
}
