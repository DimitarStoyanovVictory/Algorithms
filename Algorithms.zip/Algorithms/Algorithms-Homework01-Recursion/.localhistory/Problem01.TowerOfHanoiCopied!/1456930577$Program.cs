﻿public class TowerOfHanoi
{
    p
}
